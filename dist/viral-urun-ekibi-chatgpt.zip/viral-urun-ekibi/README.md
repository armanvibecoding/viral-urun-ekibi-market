# Viral Ürün Ekibi — ChatGPT paketi

Bu klasör `docs/chatgpt_paketi_yap.sh` ile üretildi; elle düzenleme (bir sonraki üretimde silinir).
Başlangıç: sohbette "ekibi başlat" yaz → `ekip-lideri` becerisi devreye girer. Hafıza her cevabın sonundaki DURUM bloğudur.

| Beceri | Tür |
|---|---|
| `ai-video-kreatif` | iş akışı |
| `aliexpress-firsat` | iş akışı |
| `ekip-lideri` | iş akışı |
| `kesfet-urun-avi` | iş akışı |
| `magaza-kurucu` | iş akışı |
| `reklam-kutuphanesi-avi` | iş akışı |
| `teklif-ve-sayfa` | iş akışı |
| `video-kurgu` | iş akışı |
| `firsat-avcisi` | rol |
| `icerik-stratejisti` | rol |
| `kanit-savcisi` | rol |
| `kreatif-analisti` | rol |
| `ses-tasarimcisi` | rol |
| `video-elestirmen` | rol |
| `ekip-bilgi` | bilgi |
