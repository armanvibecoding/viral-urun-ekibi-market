---
name: ekip-bilgi
description: "Viral Ürün Ekibi'nin ortak bilgi bankası: viral ürün DNA'sı (kapılar, 7 ölçüt, M1–M14 mekanizmaları), marka skoru, sözlük, ADHD dostu cevap kuralları, 600+ ürünlük Instagram kataloğu, 116 viral video kreatif notu, 80 değerlendirilmiş AliExpress adayı ve ölçülmüş dersler. \"Şu ürün viral olur mu\", \"buna benzer ne var\", \"bu kategoride hangi kanca tuttu\", \"bu ürünü daha önce inceledik mi\", \"bu hesap marka mı\" sorularında ve diğer ekip becerileri skills/ekip-bilgi/references/ altındaki bir dosyaya atıf yaptığında kullan."
---

# Ekip bilgi bankası

Diğer ekip becerilerinin ortak kaynağı. Cevap vermeden önce ilgili dosyada ara (ürün adı, kategori, kanca kelimesi);
sayıyı ve linki dosyada nasılsa öyle aktar, dosyada yoksa "kayıtta yok" de. Genel bilgiyle doldurduğun yeri "tahmin" diye işaretle.

## Hangi soruda hangi dosya
Tam tablo: `references/bilgi/README.md`. Kısa yol:

| Soru | Dosya |
|---|---|
| Viral olur mu? Kapılar, 7 ölçüt, mekanizmalar | `references/viral-dna.md` |
| Hesap örnek alınacak marka mı? | `references/marka-skoru.md` |
| Benzer ürün, kategori, izlenme | `references/bilgi/urun-katalogu.md` |
| Hangi kanca/sahne tuttu | `references/bilgi/kreatif-notlar.md` |
| Daha önce incelendi mi, neden elendi | `references/bilgi/firsat-gecmisi.md`, `references/bilgi/dersler.md` |
| 30 video planı örnekleri | `references/bilgi/uretim-deneyimi.md` |
| Terimler | `references/sozluk.md` |
| Cevap biçimi | `references/adhd-kurallari.md` |
| ChatGPT'de tek parça iş akışı metinleri | `references/chatgpt/` |
| Kollar arası dosya alışverişi (`urun-paketi.json`, `magaza-paketi.json`, `video-paketi.json`) | `references/sozlesme/arayuz-sozlesmesi.md`, betik `references/paket.py` |

## Okuma kuralları
- Kod numaraları kanıt izidir: `S063` ürün = `kreatif-notlar.md` içinde **063** notu.
- Sayılar gözlem anındaki değerlerdir; karar öncesi yeniden açılır.
- Bu dosyalarda kullanıcı verisi yoktur; kullanıcının kendi işi DURUM bloğunda ve ürettiğin dosyalarda tutulur.
