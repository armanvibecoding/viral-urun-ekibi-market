# B2 · Mobil banner (metinli, 4:5) (hazır istem şablonu, 0.3.6)

**HAZIR İSTEM.** İstemi sen YAZMAZSIN. `İSTEM BAŞI` ile `İSTEM SONU` arasındaki metni al, YALNIZ `{…}` yer tutucularını DEVAM KARTI'ndan doldur, gerisini KELİMESİ KELİMESİNE görsel aracına ver. Kısaltma, özetleme, yeniden yazma, cümle çıkarma, çeviri YASAK. Tek çağrı = tek görsel. İstemi kullanıcıya gösterme; isterse `.txt` dosyası olarak ver.

- Ne zaman: B1'den sonra; ayrı dizgi (B1 kırpılmaz); teslim 1080×1350.
- Ekler (her çağrıda YENİDEN eklenir): Ek 1 = orijinal ürün fotoğrafı · Ek 2 = onaylı G1 (önceki görsel "düzenlenmez"; her görsel yeniden üretilir)
- Üretimden sonra: `scripts/duzelt.py zemin` → kontrol listesi (`kabul-kontrolu.md` §2b); ihlal varsa göstermeden 1 kez yeniden üret (`{DÜZELTME}` dolu).

## Yer tutucular (yalnız bunlar değişir)
- `{BAŞLIK_SATIRLARI}`: 3 kısa satır, BÜYÜK HARF, tırnak içinde ` / ` ile (ör. `"PROFESYONEL" / "ELLER İÇİN" / "KAVİSLİ KESİM."`); B1 başlığının aynısı, yalnız kırılım farklı
- `{KÜÇÜK_ETİKET}`: tek satır, BÜYÜK HARF, ürünün somut adı (ör. `7,25 İNÇ KAVİSLİ CHUNKER MAKAS`)
- `{ALT_METİN}`: tek cümle, doğrulanmış bilgi
- `{BUTON}`: 2 kelime, BÜYÜK HARF (ör. `MAKASI İNCELE`)
- `{ÜRÜN_DURUŞU}`: ürün ince-uzunsa (makas, fırça, kalem, tüp, şişe) aynen `köşegen, yataydan 35° eğik, bir ucu sağ altta, öbür ucu sol üste doğru (başlığın altına kadar); boyu tuval genişliğinin %88'i; kamera kuşbakışı`; değilse aynen `dik, önden hafif üç çeyrek açı, yatayda ortalı; yüksekliği tuval yüksekliğinin %46'sı; kamera göz hizasında`
- `{ÜRÜN_ADI_VE_ÖLÇÜ}`: ürünün somut adı + doğrulanmış ölçü (ör. `7,25 inç profesyonel pet kuaför makası`)
- `{ÜRÜN_KİLİDİ_PARÇALARI}`: `<marka>-istem-bloklari.md` dosyasındaki parça parça kilit (≥ 5 cümle: biçim ve kıvrım yönü, parça SAYILARI, "X DEĞİL" karşıtları, renk/yüzey, duruş); her şablonda karakter karakter aynı
- `{ETİKET_İSTİSNASI}`: ürünün kendi satılan ambalaj etiketi korunacaksa aynen `İstisna: ürünün kendi ambalaj etiketi Ek 1 ile harf harf aynı kalır.`; yoksa yer tutucuyu sil
- `{ZEMİN_HEX}`: DEVAM KARTI "Görsel zemini" (ad + HEX, ör. `koyu petrol #0F2B2E`)
- `{METİN_HEX}`: görsel ana metin rengi (ad + HEX)
- `{İKİNCİL_HEX}`: görsel ikincil metin rengi (ad + HEX)
- `{KART_HEX}`: zeminin bir ton açığı/koyusu kart yüzeyi (HEX)
- `{VURGU_HEX}`: tek vurgu (ad + HEX); ürünün baskın renginden OLMAZ
- `{ÜRÜN_RENGİ}`: ürünün baskın renginin adı, büyük harfle başlar (ör. `Pembe`)
- `{NİŞ_YASAKLARI}`: nişe özel yasak öğeler, sonunda noktalı virgül (ör. `pati izi, tüy yığını;`); yoksa sil
- `{DÜZELTME}`: ilk denemede sil; yeniden üretimde aynen `DÜZELTME (önceki deneme bu yüzden REDdedildi; KESİN düzelt): <ret nedeni>`

=== İSTEM BAŞI ===
Sen üst düzey bir marka ajansında sanat yönetmenisin. YALNIZ 1 görsel üret: kolaj, ızgara, yan yana varyasyon, çok panel ya da mockup çerçevesi değil. Ek 1 = ürün fotoğrafı (yalnız ürün referansı; içindeki yazı, logo, zemin ve düzen YOK SAYILIR). Ek 2 = aynı markanın onaylı galeri karesi: ondan YALNIZ yazı tipi sistemini, renkleri, boşluk ritmini ve kalite seviyesini al; düzenini, metinlerini ve ürünün açısını KOPYALAMA.

ÜRÜN KİLİDİ: Ek 1 ürünün TEK doğru kaynağıdır; ürünü birebir koru, yeniden tasarlama. Ürün: {ÜRÜN_ADI_VE_ÖLÇÜ}. {ÜRÜN_KİLİDİ_PARÇALARI} Ürün yüzeyi DÜZ ve temiz: gravür, üretici logosu, amblem, kazıma yazı, harf ya da rakam YOK (Ek 1'de üründe görünen küçük gravürü SİL, kopyalama). {ETİKET_İSTİSNASI} Biçim, renk, parça sayısı ya da sayılan parçalardan biri değişirse görsel REDdedilir. Ek 1'deki yazıları, logoyu, zemin rengini, düzeni ve açıyı YOK SAY ve KOPYALAMA; Ek 1 yalnız ürünün kendisi için referanstır.

RENK (yalnız bunlar): Zemin {ZEMİN_HEX}; DÜZ ve kesintisiz tek renk, dört köşede aynı; degrade, vinyet, ışık lekesi, hale, doku YOK. Ana metin {METİN_HEX}. İkincil metin {İKİNCİL_HEX}. Kart yüzeyi {KART_HEX}. Tek vurgu rengi {VURGU_HEX} ve görselde yalnız TEK küçük öğede. {ÜRÜN_RENGİ} yalnız ürünün kendisinde; {ÜRÜN_RENGİ} yazı, çizgi, şekil, zemin YOK.
TİPOGRAFİ (bir marka sistemi; her görselde aynı): Başlıklar DAR (condensed) grotesk, BÜYÜK HARF, SemiBold; Barlow Condensed / Oswald ailesine benzer uzun-dar harfler (Barlow Condensed SemiBold ya da Oswald benzeri dar grotesk); harf aralığı sıkı, satır aralığı 0,95; başlık büyük ve kendinden emin, tasarımın ana öğesi. Başlık TEK renk: bütün satırlar ana metin renginde; iki renkli başlık, renkli kelime, ince ağırlıklı satır YOK. Başlık satır satır, METİNLER'deki kırılımla dizilir. Poppins, Montserrat ve benzeri geniş geometrik yazı tipi = RED; bu dar grotesk aile markanın tek başlık ailesidir, başka başlık ailesi KULLANILMAZ. Gövde ve açıklamalar: sade grotesk (Inter benzeri) Regular, cümle düzeni. Küçük etiketler: aynı grotesk Medium, BÜYÜK HARF, harf aralığı geniş (+%12). Başka yazı tipi YOK; serif YOK; italik YOK; el yazısı YOK. Bütün metinler tek sol hatta hizalı (aksi yazmıyorsa). Metin düz vektör gibi keskin. Türkçe harfler birebir doğru: İ, ı, ğ, ş, ç, ö, ü (büyük harfte i → İ, ı → I). Yazım hatası olan görsel REDdedilir.
IŞIK: temiz stüdyo ürün fotoğrafı; ürün gerçek fotoğraf gibi keskin; altında yalnız çok hafif, kısa temas gölgesi.

DÜZEN (web sitesi ana sayfa MOBİL BANNER; dikey 4:5): Tipografi görselin içinde ve tasarımın parçası. Üst %45 metin bloğu, sol hizalı: küçük etiket; dev başlık 3 satır, satır aralığı 1,1 (satırlar birbirine değmez; harf yüksekliği tuval genişliğinin %9–11'i); 2 satır alt metin (ikincil renk); buton (ana metin renginde dolu, köşeleri hafif yuvarlak dikdörtgen; yazısı zemin renginde, dar grotesk BÜYÜK HARF SemiBold). Alt %55: ürün BÜYÜK, {ÜRÜN_DURUŞU}; ürünün TAMAMI kadrajda, biçimi Ek 1'deki gibi (kıvrım, oran, parça sayısı aynı; kısaltılmış, yuvarlatılmış, sadeleştirilmiş ürün = RED). Küçük ürün + boş zemin YASAK; ürün metne, butona ve kenarlara değmez. İ harflerinin noktası üst satıra değmez. Vurgu rengi: YALNIZ küçük etiketin solundaki küçük dolu kare nokta.
METİNLER (yalnız bunlar, birebir):
Küçük etiket: "{KÜÇÜK_ETİKET}"
Başlık (satır satır): {BAŞLIK_SATIRLARI}
Alt metin: "{ALT_METİN}"
Buton: "{BUTON}"
ÇIKTI: tek görsel, dikey 4:5.

YASAKLAR: insan, el, hayvan fotoğrafı; taş, kaide, bitki, çiçek, kumaş, duman, sis, parlama (glow), ışık hüzmesi, bokeh, yansıma havuzu, organik leke (blob), dalga, yay ve kavis biçimli süs, kalp, yıldız, rozet, mühür, hap içine alınmış etiket, ok işareti, çizgi ikon, piktogram; {NİŞ_YASAKLARI} büyüteç dairesi; "DETAY 01" gibi numaralı etiket; "detay" kelimesi; keyfi süs çizgisi; degrade; marka adı ya da logo; harf aralığı açılmış marka adı etiketi; kargo, teslimat, indirim, kampanya, fiyat, garanti, puan, yorum, yüzde ile ilgili HER yazı; METİNLER bölümünde olmayan HER yazı. Bu istemdeki renk kodlarını, ölçüleri, blok adlarını görsele YAZMA. Hiçbir öğe (ürün dahil) tuval kenarına değmez; her kenarda tuvalin en az %7'si boş zemin kalır, ürün kenarda kesilmez. Tuvalin yarısı boş zemin kalmaz.

{DÜZELTME}
=== İSTEM SONU ===
